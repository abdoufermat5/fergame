-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: fergame
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `arme`
--

DROP TABLE IF EXISTS `arme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `arme` (
  `code_arme` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` set('fusil','epee','mitrailleuse','pistolet','lance-roquette','fusil-precision','missile') NOT NULL,
  `xps_coup` int(10) unsigned NOT NULL,
  `prix_A` decimal(9,2) NOT NULL,
  `nom_A` varchar(50) NOT NULL,
  PRIMARY KEY (`code_arme`)
) ENGINE=InnoDB AUTO_INCREMENT=1026 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arme`
--

LOCK TABLES `arme` WRITE;
/*!40000 ALTER TABLE `arme` DISABLE KEYS */;
INSERT INTO `arme` VALUES (404,'epee',70,8000.00,'Excalibur'),(405,'epee',70,10000.00,'Blue Rose Sword'),(501,'mitrailleuse',100,9500.00,'PKM'),(502,'mitrailleuse',105,9700.00,'M240'),(604,'pistolet',100,7000.00,'Beretta 92'),(605,'pistolet',105,7400.00,'Colt_45'),(606,'pistolet',110,7800.00,'Colt M1911'),(607,'pistolet',1000,100000.00,'Desert EAGLE'),(701,'lance-roquette',1000,100000.00,'AT-4'),(805,'fusil',50,7500.00,'AK-47'),(806,'fusil',90,8500.00,'M 16'),(807,'fusil',100,10000.00,'KALACHNIKOV RPK'),(901,'fusil-precision',1000,100000.00,'SIG 550 SNIPER'),(902,'fusil-precision',1050,105000.00,'M24 SWS'),(903,'fusil-precision',1000,100000.00,'VKS'),(1024,'missile',2000,1000000.00,'SS-9 SCARP'),(1025,'missile',2500,1500000.00,'SS-18 SATAN');
/*!40000 ALTER TABLE `arme` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-13 22:53:06
