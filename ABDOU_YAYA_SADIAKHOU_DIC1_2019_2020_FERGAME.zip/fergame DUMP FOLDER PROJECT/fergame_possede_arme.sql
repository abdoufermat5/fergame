-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: fergame
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `possede_arme`
--

DROP TABLE IF EXISTS `possede_arme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `possede_arme` (
  `code_arme` int(10) unsigned NOT NULL,
  `id_perso` tinyint(3) unsigned NOT NULL,
  KEY `id_perso` (`id_perso`),
  KEY `code_arme` (`code_arme`),
  CONSTRAINT `possede_arme_ibfk_1` FOREIGN KEY (`id_perso`) REFERENCES `personnage` (`id_perso`),
  CONSTRAINT `possede_arme_ibfk_2` FOREIGN KEY (`code_arme`) REFERENCES `arme` (`code_arme`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `possede_arme`
--

LOCK TABLES `possede_arme` WRITE;
/*!40000 ALTER TABLE `possede_arme` DISABLE KEYS */;
INSERT INTO `possede_arme` VALUES (404,1),(604,1),(606,2),(405,2),(501,2),(605,2),(807,3),(1024,3),(902,3),(1024,4),(901,4),(805,4),(701,4),(805,5),(404,5),(1025,6),(903,6),(701,6),(605,7),(806,7),(604,8),(805,9),(501,9),(404,10),(607,10),(903,11),(701,11),(806,11);
/*!40000 ALTER TABLE `possede_arme` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-13 22:53:05
