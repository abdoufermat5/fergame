-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: fergame
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `joueur`
--

DROP TABLE IF EXISTS `joueur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `joueur` (
  `pseudo_joueur` varchar(30) NOT NULL,
  `password` varchar(60) NOT NULL,
  `email` varchar(200) NOT NULL,
  `pays` varchar(45) NOT NULL,
  `points_j` int(11) DEFAULT '1000',
  `date_inscription` datetime NOT NULL,
  `niveau_j` set('Debutant','Moyen','Professionnel','Legende') DEFAULT 'Debutant',
  `fonds` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`pseudo_joueur`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `joueur`
--

LOCK TABLES `joueur` WRITE;
/*!40000 ALTER TABLE `joueur` DISABLE KEYS */;
INSERT INTO `joueur` VALUES ('abdou','Lebron1@','abdou@ept.sn','USA',33255,'2011-12-24 11:05:54','Professionnel',5000000.00),('adja','ada907','ada7@yahoo.com','Senegal',19988,'2017-01-04 06:02:34','Debutant',250000.00),('allan','alpo99$','allie5@hotmail.es','Espagne',57800,'2015-07-14 23:55:46','Professionnel',60000000.00),('alvin','alvi56_@','alvin155@yahoo.fr','France',2500,'2019-01-24 13:35:08','Moyen',14884500.00),('baidy','cr71885','bdsy7@gmail.com','Senegal',62340,'2017-04-04 18:25:48','Professionnel',15000000.00),('cristiano','cr700but','thegoat@gmail.com','Portugal',10090000,'2019-05-14 14:07:01','Legende',475000000.00),('edgar','eddie777','edgar77@hotmail.com','USA',2120000,'2019-10-30 07:56:22','Legende',198885000.00),('fermat','$45_@xyz','fermat@gmail.com','Senegal',975,'2011-11-24 15:35:56','Debutant',240000.00),('fode','21fode','fofo12@gmail.com','Senegal',85440,'2013-09-14 12:45:08','Professionnel',28880000.00),('junior','jun1298','Hisself@hotmail.com','Canada',24885,'2013-11-24 05:35:08','Moyen',6885000.00),('messi','leo101988','leomessi@hotmail.com','Argentine',10035000,'2019-02-13 09:35:45','Legende',525000000.00);
/*!40000 ALTER TABLE `joueur` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-13 22:53:05
