-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: fergame
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dispose_equipement`
--

DROP TABLE IF EXISTS `dispose_equipement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dispose_equipement` (
  `id_equipement` int(10) unsigned NOT NULL,
  `id_perso` tinyint(3) unsigned NOT NULL,
  KEY `id_equipement` (`id_equipement`),
  KEY `id_perso` (`id_perso`),
  CONSTRAINT `dispose_equipement_ibfk_1` FOREIGN KEY (`id_equipement`) REFERENCES `equipement` (`id_equipement`),
  CONSTRAINT `dispose_equipement_ibfk_2` FOREIGN KEY (`id_perso`) REFERENCES `personnage` (`id_perso`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dispose_equipement`
--

LOCK TABLES `dispose_equipement` WRITE;
/*!40000 ALTER TABLE `dispose_equipement` DISABLE KEYS */;
INSERT INTO `dispose_equipement` VALUES (1005,1),(1005,2),(1001,2),(1002,2),(1001,3),(1005,3),(1003,3),(1004,3),(1001,4),(1002,4),(1003,4),(1005,4),(1005,5),(1002,6),(1003,6),(1004,6),(1005,6),(1005,7),(1005,8),(1005,9),(1001,10),(1004,10),(1005,10),(1001,11),(1002,11),(1004,11),(1005,11);
/*!40000 ALTER TABLE `dispose_equipement` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-13 22:53:06
