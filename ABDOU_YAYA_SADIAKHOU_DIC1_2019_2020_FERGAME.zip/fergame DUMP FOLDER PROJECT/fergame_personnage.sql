-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: fergame
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `personnage`
--

DROP TABLE IF EXISTS `personnage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personnage` (
  `id_perso` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `nom_perso` varchar(50) NOT NULL,
  `pseudo_joueur` varchar(30) DEFAULT NULL,
  `niveau_p` set('1','2','3','4','5') NOT NULL,
  `point_vie_restant` int(10) unsigned NOT NULL DEFAULT '100',
  `prix_perso` set('10000','100000','10000000','50000000','75000000') DEFAULT NULL,
  PRIMARY KEY (`id_perso`),
  KEY `pseudo_joueur` (`pseudo_joueur`),
  CONSTRAINT `personnage_ibfk_1` FOREIGN KEY (`pseudo_joueur`) REFERENCES `joueur` (`pseudo_joueur`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personnage`
--

LOCK TABLES `personnage` WRITE;
/*!40000 ALTER TABLE `personnage` DISABLE KEYS */;
INSERT INTO `personnage` VALUES (1,'Merlin','junior','2',1450,'100000'),(2,'Dracula','allan','4',5000,'50000000'),(3,'Chuck Norris','edgar','5',7500,'75000000'),(4,'Arnold Swarzi','cristiano','5',8500,'75000000'),(5,'Skywalker','alvin','2',505,'100000'),(6,'Travolta','messi','5',7800,'75000000'),(7,'JCVD','baidy','3',4500,'10000000'),(8,'JACK RYAN','fermat','1',0,'10000'),(9,'Armagedon','adja','2',2500,'100000'),(10,'Asbald','abdou','3',3405,'10000000'),(11,'DROGON','fode','4',4850,'50000000'),(12,'Thor',NULL,'5',100,'75000000'),(13,'Achille',NULL,'3',100,'10000000'),(14,'SKULL',NULL,'4',100,'50000000'),(15,'IronSide',NULL,'1',100,'10000'),(16,'GHOST SNIPER',NULL,'2',100,'100000'),(17,'DARK KILLER',NULL,'5',100,'75000000');
/*!40000 ALTER TABLE `personnage` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-13 22:53:06
